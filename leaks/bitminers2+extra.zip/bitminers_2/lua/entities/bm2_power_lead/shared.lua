ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Power Lead"
ENT.Spawnable = true
ENT.Category = "Bitminers 2"


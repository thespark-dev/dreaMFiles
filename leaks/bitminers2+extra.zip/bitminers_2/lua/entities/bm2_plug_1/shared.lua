ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Extention Lead"
ENT.Spawnable = false
ENT.Category = "Bitminers 2"

function ENT:SetupDataTables()

end
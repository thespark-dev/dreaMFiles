ENT.Type = "anim"
ENT.Base = "bm2_base"

ENT.PrintName = "Fuel Tank Line End"
ENT.Spawnable = false
ENT.Category = "Bitminers 2 Extras"
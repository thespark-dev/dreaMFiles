ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "BM2 base"
ENT.Spawnable = false
ENT.Category = "Bitminers 2"


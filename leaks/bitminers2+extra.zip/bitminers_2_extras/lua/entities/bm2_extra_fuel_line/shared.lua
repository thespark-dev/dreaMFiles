ENT.Type = "anim"
ENT.Base = "bm2_base"

ENT.PrintName = "Fuel Line"
ENT.Spawnable = true
ENT.Category = "Bitminers 2 Extras"
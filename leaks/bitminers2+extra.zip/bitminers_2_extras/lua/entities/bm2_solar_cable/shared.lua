ENT.Type = "anim"
ENT.Base = "bm2_base"

ENT.PrintName = "Solar Cable"
ENT.Spawnable = true
ENT.Category = "Bitminers 2 Extras"

function ENT:SetupDataTables()

end
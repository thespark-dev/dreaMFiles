ENT.Type = "anim"
ENT.Base = "bm2_base"

ENT.PrintName = "Solar Cable Other End"
ENT.Spawnable = false
ENT.Category = "Bitminers 2 Extras"

function ENT:SetupDataTables()

end
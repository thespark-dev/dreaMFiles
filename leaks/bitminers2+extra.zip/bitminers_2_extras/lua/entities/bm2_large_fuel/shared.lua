ENT.Type = "anim"
ENT.Base = "bm2_base"

ENT.PrintName = "Large Fuel"
ENT.Spawnable = true
ENT.Category = "Bitminers 2 Extras"

